﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chicken.Model.Entity
{
    public class HashTag
    {
        public string Text { get; set; }
    }
}
