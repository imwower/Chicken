﻿
using Chicken.Model.Entity;
namespace Chicken.ViewModel.Status.Base
{
    public class CoordinatesViewModel
    {
        private Coordinates coordinates;

        public CoordinatesViewModel(Coordinates coordinates)
        {
            this.coordinates = coordinates;
        }

        public double X
        {
            get
            {
                return coordinates.Points[0];
            }
        }

        public double Y
        {
            get
            {
                return coordinates.Points[1];
            }
        }

        public override string ToString()
        {
            return (int)X + ", " + (int)Y;
        }
    }
}
